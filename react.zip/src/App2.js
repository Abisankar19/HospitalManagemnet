import React, { Component } from 'react';
import ReactDOM from "react-dom"; 
import { BrowserRouter as Router } from 'react-router-dom';
import Sidebar from "./Sidebar";
import axios from 'axios';
import logo from './logo.svg';
// import { StyleSheet, Text, View} from 'react-native';

// import { API, graphqlOperation, Auth } from 'aws-amplify'
// import { ListTodos } from './api/contacts.php'
const API_URL = 'http://jsonplaceholder.typicode.com';

export default class App extends Component {
  // [...]
  	constructor(props){
	  	super(props);
		this.state = {
		    contacts: []
	  	}
  	}
  	async componentDidMount() {
	    // Auth.currentCredentials()
	    const url = 'http://localhost/api/contacts.php'
	    axios.get(url).then(response => response.data)
	    .then((data) => {
        let val = JSON.parse(`[${data}]`);
        this.setState({ contacts: val })
        console.log(this.state.contacts)
	     })
  	}

  	render() {
    return (
        <React.Fragment>
        <h1>Contact Management</h1>
        <table border='1' width='100%' >
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Country</th>
            <th>City</th>
            <th>Job</th>     
        </tr>

        {this.state.contacts.map((contact) => (
        <tr>
            <td>{ contact.name }</td>
            <td>{ contact.email }</td>
            <td>{ contact.country }</td>
            <td>{ contact.city }</td>
            <td>{ contact.job }</td>
        </tr>
        ))}
        </table>
        <div>
        <Router>
          <Sidebar path="/side" />
        </Router>
        </div>

        </React.Fragment>
    );
  }
}



