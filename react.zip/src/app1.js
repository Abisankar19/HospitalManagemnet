import ReactDOM from "react-dom"; 
import { BrowserRouter as Router } from 'react-router-dom';
import Sidebar from "./Sidebar";

const App = () => {
  return (
      <div>
        <header>
          <Link to="/">Adopt Me!</Link>
        </header>
        <Router>
          <Sidebar path="/" />
        </Router>
      </div>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
