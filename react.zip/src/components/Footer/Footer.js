import React, {Component} from 'react';
import '../../styles/custom.css';
class Footer extends Component {
render() {
return (
<div className="row" id="footer">
<div className="medium-12 columns">
<p>Copyright 2020 , <a href="https://jpclass.sathisys.com"> sathisys</a></p>
</div>
</div>
);
}
}
export default Footer;