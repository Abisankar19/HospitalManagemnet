import React, { Component } from 'react';
import { connect } from "react-redux";
import './Header.css';
class Header extends Component {
constructor(props) {
        super(props)
	  	this.logoutHandler = this.logoutHandler.bind(this);
	  	
    }
logoutHandler =(e) => {
		window.localStorage.removeItem('user');
		window.localStorage.clear();
    	window.location.href = '/Login';
    }	
render() {
		let comp;
		let List_comp;
		let tok_comp;
		if(window.localStorage.getItem("user")){
			comp = <a href="#" className="menu" onClick={e=>this.logoutHandler(e)}>Logout</a> 
			List_comp = <a href="/List" className="menu">List</a>
			tok_comp = <a href="/shop" className="menu">Token</a> 
		}
return (
<div className="callout headcolor" id="Header">
<a href="/"><h1 id="tit">{this.props.name}</h1></a>
<a href="/Login" className="menu">Home</a>
<a href="/Register" className="menu">Register</a>
{List_comp}
{tok_comp}
<div className="logout">
{comp}
</div>
</div>
);
}
}

export default Header;