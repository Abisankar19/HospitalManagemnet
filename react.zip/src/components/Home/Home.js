import React from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import Login from '././components/Login/Login';
class Home extends React.Component {
	state= { user:null }


	setUser=user => {
		this.setState({user: user})

	}

		render() {
			return(
				<BrowserRouter>
					<Switch>
						{this.state.user== null ? (
							<Route path="/login" render={() => {
								return (
									<div>
										<Login user ={this.state.user} setUser={this.setUser} />
									</div>

								)
							}}   />

						)	:   (	  

                                 <Route path="/home" render={() => {
                                 	return (
                                 		<div>
                                 			<Home user={this.state.user}setUser={this.setUser} />
                             			</div>
                         			)	

                         		}}/>)}
             		</Switch>
         		</BrowserRouter>
     		)
 		}
}
export default Home;

								

						
									

									
										
									
								







									





































