import React, { Component } from 'react';
import ReactDOM from "react-dom"; 
import { BrowserRouter as Router } from 'react-router-dom';
import axios from 'axios';
import './List.css';
import Header from '../Header/Header';
import ReactPaginate from 'react-paginate';
// import { StyleSheet, Text, View} from 'react-native';

// import { API, graphqlOperation, Auth } from 'aws-amplify'
// import { ListTodos } from './api/contacts.php'
const API_URL = 'http://jsonplaceholder.typicode.com';

export default class List extends Component {
  // [...]
  	constructor(props){
        super(props);
  		this.state = {
            pagename:"",
  		    contacts: [],
            offset: 0,
            perPage: 3,
            currentPage: 0,
  	  	}
        this.handlePageClick = this.handlePageClick.bind(this);
  	}
    handlePageClick = (e) => {
        const selectedPage = e.selected;
        const offset = selectedPage * this.state.perPage;

        this.setState({
            currentPage: selectedPage,
            offset: offset
        }, () => {
            this.Listview()
        });

    };
    Listview(){
        const url = 'http://localhost/api/contacts.php'
        if(this.props.location.state.id == "123"){ 
            axios.get(url).then(response => response.data)
            .then((data) => {
                // alert(JSON.stringify(data));
                // let val = JSON.parse(`[${data}]`);
                const data1 = data;
                const slices = data1.slice(this.state.offset, this.state.offset + this.state.perPage);
                // const postData = slices.map;
                // console.log(postData);
                this.setState({ contacts: slices,pageCount: Math.ceil(data1.length / this.state.perPage) })
                // this.setState({ contacts: val })
            })
        }
    }
  	async componentDidMount() {
	    this.Listview();
	    
  	}

  	render() {
    const pagename = "active";   
    let url="/Register?name=";
    return (
        <React.Fragment>
        <h3><image src="../download.png"/>Hospital Management</h3>
        <table border='1' width='100%' >
        <tr className="hdr">
            <th colSpan="1" align="center">S.No</th>
            <th colSpan="4">Name</th>
            <th colSpan="4" align="center">Age</th>
            <th colSpan="1">Blood Group</th>     
            <th colSpan="1">Disease</th>
            <th colSpan="1">Address</th>
        </tr>

        {this.state.contacts.map((contact,index) => (
        <tr>
            <td colSpan="1" align="center">   { contact.id } </td>
            <td colSpan="4"><a href={ "/Register?edit_id=" + contact.id }>{contact.name}</a></td>
            <td colSpan="4" align="center">   { contact.age } </td>
            <td colSpan="1">   { contact.blood_group } </td>
            <td colSpan="1">  { contact.disease }</td>
            <td colSpan="1" align="center">   { contact.address } </td>
        </tr>
        ))}
        </table>
        <div align="center" style ={{marginRight: "92px"}}>
            
             </div>
        </React.Fragment>
    );
  }
}



