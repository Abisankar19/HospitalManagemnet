import React, { Component } from 'react';
import ReactDOM from "react-dom"; 
import { BrowserRouter as Router,Redirect } from 'react-router-dom';
import axios from 'axios';
import App from '../../App';
import Header from '../Header/Header';
import './login.css';
class Login extends Component {
	constructor(props){
	  super(props);
	  this.state = {
		    username: "",
		    password: "",
		    redirect: "",
		    invalid: ""
	  	}
	  // this.handleSubmit = this.handleSubmit.bind(this);
	 }
	// handlechange= e=>this.setState({ [e.target.name]: e.target.value})

	handleSubmit= async e => {
		e.preventDefault() 
		/*const requestOptions = {
	        mode: 'no-cors',
	        method: "POST",
	        body: { username:"bajkn"},
    	};
    	const headers = {
		  'Content-Type': 'application/json',
		}*/
		const data = {data:{
			username : this.state.username,
			password : this.state.password
		}
		}

		/*axios.post(Helper.getUserAPI(), data, {
		    headers: headers
		  })*/
		await axios.post("http://localhost/api/login.php", JSON.stringify(data)).then( (res) => {
	      	console.log(res.data);
	      	// alert(JSON.stringify(res.data));
	      	if (JSON.stringify(res.data.success)) {
	      			window.localStorage.setItem('user', res.data.name);
		      		this.setState({
		                redirect: "/List"
		            })
		      } else if (res.status === 401) {
		        alert("Oops! ");
		      } else{
		      	this.setState({
		                invalid: "logout"
		            })
		      }
		    }, function (e) {
		      alert("Error submitting form!");
		      console.log(e);
		    });
	}


	render(){
		const log_in = '1';
		if (this.state.redirect) {
		    return (<div>
		    		<Redirect to={{
            					pathname: this.state.redirect,
            					state: { id: '123' }
        						}}
		/></div>)
	  	}
		return (
			<div className="model">
				<h1 className="hone">Login</h1>
					<p className="loginerr">{this.state.invalid ? 'Invalid Password' : ''}</p>
				<form className="modal-content animate" onSubmit={this.handleSubmit}>
				<div className="container">
					<label>Username: </label>
					<input type="text"  placeholder="username" onChange={e => this.setState({username: e.target.value})} />
					<label>Password: </label>
					<input type="password" placeholder="password" onChange={e => this.setState({password: e.target.value})} />
					<button type="Submit">login</button>
					<a href="/Register" className="signup">Signup</a>
					<a href="#" className="">Forgot Password</a>
				</div>
				</form>
			</div>
		)
	}
}
export default Login;






