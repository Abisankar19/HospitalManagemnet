import React, { Component } from 'react';
import { MuiThemeProvider } from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import RaisedButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link, useLocation, BrowserRouter as Router } from "react-router-dom";
import axios from 'axios';
import Moment from 'moment';
import './Register.css';
import Login from '../Login/Login';

class Register extends Component {
constructor(props){
    super(props);
    const user = this.useQuery();
    this.state={
      clickevnt : "",
      message:"",
      errors: {},
      id :"",  
      data:{
            name:'',
            blood_group:'',
            age:'',
            disease:'',
            address:'',
            admit:'',
            contact:'',
            remarks:''
           } 
    }
    this.handleClick = this.handleClick.bind(this);
}
onTodoChange(event){
        this.setState({
             name: event.target.value
        });
}
async componentDidMount() {
    const url = 'http://localhost/api/login.php'
    var self = this;
    const user = this.useQuery();
    const user_val = [];

    if(user){ 
    axios.post(url+"?edit=true",JSON.stringify(user)).then(response => response.data)
        .then((data) => {
            // alert(JSON.stringify(data));
            // let val = JSON.parse({data});
        console.log(data);
        // this.setState({data: data});
        this.setState({name: data.name});
        this.setState({blood_group: data.blood_group});
        this.setState({age: data.age});
        this.setState({disease: data.disease});
        this.setState({address: data.address});
        this.setState({admit1: data.admin_date});
        this.setState({contact: data.contact_no});
        this.setState({remarks: data.remarks});
        this.setState({id: data.id});
        console.log(this.state.data);
        })
    }
}
useQuery() {
  return new URLSearchParams(this.props.location.search).get("edit_id")
}
componentWillReceiveProps(nextProps){
console.log("nextProps",nextProps);
}
handleValidation(data){
        this.setState({data: data});
        let fields = data;
        let errors = {};
        let formIsValid = true;
        // alert(fields["name"]);
        //Name
console.log(this.state);
        if(typeof fields["name"] !== "undefined"){
           if(!fields["name"].match(/^[a-zA-Z]+$/)){
              formIsValid = false;
              errors["name"] = "Only letters";
           }        
        }
        
        if(!fields["name"]){
           formIsValid = false;
           errors["name"] = "Name is required";
        }


        //blood_group
        if(!fields["blood_group"]){
           formIsValid = false;
           errors["blood_group"] = "Blood Group is required";
        }
        //disease
        if(!fields["disease"]){
           formIsValid = false;
           errors["disease"] = "Disease is required";
        }
        //age
        if(!fields["age"]){
           formIsValid = false;
           errors["age"] = "Age is required";
        }

        //address
        if(!fields["address"]){
           formIsValid = false;
           errors["address"] = "Address is required";
        }

        //admit
        if(!fields["admit"]){
           formIsValid = false;
           errors["admit"] = "Admit Date is required";
        }
        if(this.state.clickevnt ==""){
          formIsValid = false;
          errors["admit"] = "Admit Date is required"; 
        }
        //contact
        if(!fields["contact"]){
           formIsValid = false;
           errors["contact"] = "Contact is required";
        }

        //remarks
        if(!fields["remarks"]){
           formIsValid = false;
           errors["remarks"] = "Remarks is required";
        }

       //  if(typeof fields["email"] !== "undefined"){
       //     let lastAtPos = fields["email"].lastIndexOf('@');
       //     let lastDotPos = fields["email"].lastIndexOf('.');

       //     if (!(lastAtPos < lastDotPos && lastAtPos > 0 && fields["email"].indexOf('@@') == -1 && lastDotPos > 2 && (fields["email"].length - lastDotPos) > 2)) {
       //        formIsValid = false;
       //        errors["email"] = "Email is not valid";
       //      }
       // }  

       this.setState({errors: errors});
       return formIsValid;
}
handleChange = date => {
    this.setState({
      admit: date,
      admit1: ""
    });
};
restrict = (event) => {

                    const regex = new RegExp("/^[^!-\\/:-@\\[-`{-~]+$/;");

                    const key = String.fromCharCode(!event.charCode ? event.which : event.charCode);

                    if (!regex.test(key)) {

                    event.preventDefault(); return false;

                    }

                }
async handleClick(event,role){
var apiBaseUrl = "http://localhost/api/login.php";
    // console.log("values in register handler",role);
    var self = this;
    //To be done:check for empty values before hitting submit
    const data={
    "name": this.state.name,
    "blood_group":this.state.blood_group,
    "age":this.state.age,
    "disease":this.state.disease,
    "address":this.state.address,
    "admit": Moment(this.state.admit).format('YYYY-MM-DD'),
    "contact":this.state.contact,
    "remarks":this.state.remarks,
    "id":this.state.id,
    "role":role
    }

    var self = this;
    // if(this.handleValidation(data)){
        console.log(data);
        if(this.useQuery()){
            await axios.post(apiBaseUrl+"?update=true", JSON.stringify(data))
            .then(function (response) {
                if(response.data.success === 1){
                    //  console.log("registration successfull");
                    // var loginscreen=[];
                    // loginscreen.push(<Login parentContext={this} appContext={self.props.appContext} role={role}/>);
                    // var loginmessage = "Not Registered yet.Go to registration";
                    // self.props.parentContext.setState({loginscreen:loginscreen,
                    // loginmessage:loginmessage,
                    // buttonLabel:"Register",
                    // isLogin:true
                    // });
                      self.setState({ message:  response.data.message})
                } else if(response.data.errors){
                    const val = response.data.errors;
                      //   console.log(val);
                      self.setState({ errors:  val})
                } else{
                     console.log("some error ocurred",response.data.success);
                }
            })
            .catch(function (error) {
            console.log(error);
            });
        } else{
            await axios.post(apiBaseUrl+"?reg=true", JSON.stringify(data))
            .then(function (response) {
                if(response.data.success === 1){
                    //  console.log("registration successfull");
                    // var loginscreen=[];
                    // loginscreen.push(<Login parentContext={this} appContext={self.props.appContext} role={role}/>);
                    // var loginmessage = "Not Registered yet.Go to registration";
                    // self.props.parentContext.setState({loginscreen:loginscreen,
                    // loginmessage:loginmessage,
                    // buttonLabel:"Register",
                    // isLogin:true
                    // });
                    self.setState({ message:  response.data.message})

                } else if(response.data.errors){
                    const val = response.data.errors;
                      //   console.log(val);
                      self.setState({ errors:  val})
                } else{
                     console.log("some error ocurred",response.data.success);
                }
            })
            .catch(function (error) {
            console.log(error);
            });
        }
    // } else{
    //     alert("Input field value is missing");
    // }

}
render() {
    // console.log("props",this.props);
    // var userhintText,userLabel;
    // if(this.props.role === "student"){
    //   userhintText="Enter your Student Id";
    //   userLabel="Student Id";
    // }
    // else{
    //   userhintText="Enter your Teacher Id";
    //   userLabel="Teacher Id";
    // }
    return (
    <React.Fragment>
      <div style={div_}>
        <MuiThemeProvider>
            <span style={{color: "red", "margin-left": 218}}>{this.state.message}</span>
          <div>
          <AppBar
             title="Register"
           />
            <div className="lbl">
                <label className="lblmrgn">PatientS Name:</label>
            </div>    
            <TextField
                validations={[required]}
                floatingLabelText="Name" value={this.state.name}
                onChange = {(e) => {
                                      let value = e.target.value
                                      value = value.replace(/[^A-Za-z]/ig, '')
                                      this.setState({name:value,})
                                    }}
             /><span style={{color: "red"}}>{this.state.errors["name"]}</span>
            <br/>
            <div className="lbl">
              <label className="lblmrgn">Blood Groop: </label>
            </div>
            <TextField
                validations={[required]}
                floatingLabelText="Blood Groop" value={this.state.blood_group}
                onChange = {event => this.setState({blood_group: event.target.value})}
             /><span style={{color: "red"}}> {this.state.errors["blood_group"]}</span>
            <br/>
            <div className="lbl">
            <label className="lblmrgn">Age: </label>
            </div>
            <TextField
                validations={[required]}
                style={numfrmt}
                type="number" value={this.state.age}
                floatingLabelText={"Age"}
                onChange = {event => this.setState({age:event.target.value})}
                onInput = {(e) =>{
                    e.target.value = Math.max(0, parseInt(e.target.value) ).toString().slice(0,2)
                }}
             /><span style={{color: "red"}}> {this.state.errors["age"]}</span>
            <br/>
            <div className="lbl">
                <label className="lblmrgn">Disease: </label>
            </div>
            <TextField
                validations={[required]}
                floatingLabelText="Disease" value={this.state.disease}
                onChange = {(e) => {
                                      let value = e.target.value
                                      value = value.replace(/[^A-Za-z]/ig, '')
                                      this.setState({disease:value,})
                                    }}
             /><span style={{color: "red"}}> {this.state.errors["disease"]}</span>
            <br/>
            <div className="lbl">
                <label className="lblmrgn">Address: </label>
            </div>
            <textarea 
                validations={[required]}
                className="addr"
                floatingLabelText="Address" value={this.state.address}
                onChange = {event => this.setState({address:event.target.value})}
             /><span  style={addr_lbl}> {this.state.errors["address"]}</span>
            <br/>
            <div className="lbl">
                <label className="lblmrgn">Admint Date: </label>
            </div>
            {this.state.admit1 !=""?<DatePicker
                value={this.state.admit1}
                onChange={this.handleChange}
                dateFormat="yyyy-MM-dd"
            />:<DatePicker
                selected={this.state.admit}
                onChange={this.handleChange}
                dateFormat="yyyy-MM-dd"
            />}
            <span style={{color: "red"}}> {this.state.errors["admit"]}</span>
            <br/>
            <div className="lbl">
                <label className="lblmrgn">contact Number: </label>
            </div>
            <TextField
                validations={[required]}
                className="numfrmt"
                style={numfrmt}
                type = "number" value={this.state.contact}
                floatingLabelText="Contact"
                onChange = {event => this.setState({contact:event.target.value})}
                onInput = {(e) =>{
                    e.target.value = Math.max(0, parseInt(e.target.value) ).toString().slice(0,10)
                }}
             /><span style={{color: "red"}}> {this.state.errors["contact"]}</span>
            <br/>
            <div className="lbl">
                <label className="lblmrgn">Remarks: </label>
            </div>
            <TextField
                validations={[required]}
                floatingLabelText="Remarks" value={this.state.remarks}
                onChange = {event => this.setState({remarks:event.target.value})}
             /><span style={{color: "red"}}> {this.state.errors["remarks"]}</span>
            <br/>
            <RaisedButton label="Submit" style={this.useQuery()?updatebtn:regbtn} onClick={(event) => this.handleClick(event,this.props.role)}>{this.useQuery()?"Update":"Register"}</RaisedButton>
            <RaisedButton label="" style={cancelbtn}>Cancel</RaisedButton>
        </div>
        </MuiThemeProvider>
    </div>
    </React.Fragment>
    );
  }
}

const required = (value) => {
  if (!value.toString().trim().length) {
    return 'require';
  }
};
const regbtn = {
    margin: "15px 226px",
    width: "90px",
    "background-color": "rgb(24, 112, 181)",
    "padding-bottom": "5px",
    color: "floralwhite",
    "letter-spacing": "0em",
    "text-transform": "initial",
    padding: "3px 0px",
};
const updatebtn = {
    margin: "15px 226px",
    width: "90px",
    "background-color": "rgb(224 135 3 / 88%)",
    "padding-bottom": "5px",
    color: "floralwhite",
    "letter-spacing": "0em",
    "text-transform": "initial",
    padding: "3px 0px",
};
const cancelbtn = {
    margin: "0px -205px",
    width: "90px",
    "background-color": "rgb(195 46 35 / 91%)",
    "padding-bottom": "5px",
    color: "floralwhite",
    "letter-spacing": "0em",
    "text-transform": "initial",
    padding: "3px 0px",
};
const div_ ={
    "margin-left": 218
}
const numfrmt ={
    "margin-top": "14px"
}
const addr_lbl={
    color: "red",
    display: "block",
    width: "max-content",
    margin: "-15px 575px 0px",
};
export default Register;
