import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { MuiThemeProvider } from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import { Redirect } from 'react-router-dom';
import RaisedButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link, useLocation, BrowserRouter as Router } from "react-router-dom";
import axios from 'axios';
import Moment from 'moment';
import swal from 'sweetalert'
import { Provider } from "react-redux";
import { createStore } from "redux";
import Header from '../Header/Header';
// import './screen-standard.css';
// import './queue-demo-standard.css';
import './shop.css';


class Shop extends Component {
constructor(props){
    // const store = createStore(reducer);
    super(props);
    this.printerData = [];
    this.state={
        redirect: "",
        data:{
                service1:'',
                service2:'',
                service3:'',
                screen : ''
               }
    }
}

async generateQueueNumber(section){
    if(window.localStorage.getItem("user") == "abi"){
        var token_path = "/Token"; 
    } else{
        var token_path = "/Token_no";  
    }
    if(section ==1){
        var b_screen = "b_screen";  
        this.setState({
                            redirect: token_path,
                            data:{
                                    service1:'Withdrawl',
                                    service2:'Deposit',
                                    service3:'New Account',
                                    screen: b_screen
                                   }
                        })
    }else if(section ==2){
        var b_screen = "b_screen";  
        this.setState({
                            redirect: token_path,
                            data:{
                                    service1:'Cardiologist',
                                    service2:'Dentist',
                                    service3:'Orthopaedic',
                                    screen:b_screen
                                   }
                        })
    }else if(section ==3){
        var b_screen = "b_screen3";  
        this.setState({
                            redirect: token_path,
                            data:{
                                    service1:'General',
                                    service2:'Over All',
                                    service3:'',
                                    screen: b_screen
                                   }
                        })
    }
    
}
render() {
    if (this.state.redirect) {
        return (<div>
                        <Redirect to={{
                                    pathname: this.state.redirect,
                                    state: { menu:  this.state.data}
                                    }}
            /></div>)
    }
    const page = "token";
    return (<div class="src" style={{margin: "6px 168px" }}>
        <ul style={{top: "437px",left: "363px",width: "215px", }}>     
            <li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(1)}>Bank</a></li><li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(2)}>Hospital</a></li><li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(3)}>Vehicle Maintanance</a></li>
        </ul>
    </div>
);
  }
}

export default Shop;
