import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { MuiThemeProvider } from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import RaisedButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link, useLocation, BrowserRouter as Router } from "react-router-dom";
import axios from 'axios';
import Moment from 'moment';
import './Raleway.css';
import './basic.css';


class Register extends Component {
constructor(props){
    super(props);
    this.printerData = [];
    this.state={
        showdata : this.printerData,
    }
    this.appendData = this.appendData.bind(this);
}
appendData(token) {
         this.printerData.push(<div  id="ticket" class="inner" style={{ bottom: "33px" }}><h3>Registration<strong>{token}</strong></h3></div>);
         this.setState({
            showdata : this.printerData,
         });
      }
async generateQueueNumber(event){
var apiBaseUrl = "http://localhost/api/login.php";
    // console.log("values in register handler",role);
    var self = this;
    //To be done:check for empty values before hitting submit
    this.printerData = [];
    axios.get(apiBaseUrl+"?token=true").then(response => response.data)
    .then((data) => {
        alert(JSON.stringify(data));
        this.appendData(data.token);
        
        console.log(data);    
    })
    .catch(function (error) {
    console.log(error);
    });
}
render() {
    return (<div class="screen">
        <input type="hidden" id="start" name="start" class="start" value="" />
        <div class="totalqueue">
            <div id="jquery_jplayer_1"></div>
            <div id="jquery_jplayer_2"></div> 
            <div id="jquery_printerPlayer"></div>
        </div> 
            
        <div class="step1">
            <div id="printer" class="slide">{this.printerData}</div>
            <div class="printer-cover"></div>
        </div>
    
        <ul class="screen3">
            <li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(event)}>Registration</a></li>
        </ul>
        <table border="0" cellspacing="4" cellpadding="0" class="jumbotron">
            <tr><td colspan="3"></td></tr>
            <tr><td colspan="3"></td></tr>
             <tr> <td class='labl'> <input type='hidden' name='serviceId' value='7'/> <input type='hidden' name='sectionId' value='7'/> Registration </td> </tr> <tr> <td ><em id='tdqueuenumbersection7StatusZ'>1004</em></td> </tr>
        </table>
        
        <ul class='payment'><li id='screen_7'><strong>Registration</strong><a href='javascript:void(0);' class='ahref' onclick='callNextQueue(7,36)'>CALL NEXT</a><a href='javascript:void(0);' class='ahref' onclick='callTopQueue(36)'>CALL AGAIN</a> </li></ul> 
    </div>);
  }
}

const required = (value) => {
  if (!value.toString().trim().length) {
    return 'require';
  }
};
const regbtn = {
    margin: "15px 226px",
    width: "115px",
    "background-color": "rgb(24, 112, 181)",
    "padding-bottom": "5px",
    color: "floralwhite",
    "letter-spacing": "0em",
    "text-transform": "initial",
    padding: "3px 0px",
};
const div_ ={
    "margin-left": 118,
    "margin-bottom": 158,
    "width": "50%"
}
const div2 ={
    "border-style": "outset",
}
const note_={
   "margin": "-179px 500px 458px",
    "width": "80%",
    "border-style": "outset",
    "color": "red",
    "display":"none",
    "padding": "64px"
}
const ahref={
    "display":"block",
    "background":"#e06522",
    "border-radius":"3px",
    "margin":"5px 0",
    "text-decoration":"none",
    "line-height":"30px",
    "color":"#fff",
    "border-bottom": "4px solid #BD4E12"
}
export default Register;
