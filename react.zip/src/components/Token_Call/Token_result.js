import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { MuiThemeProvider } from '@material-ui/core';
import AppBar from '@material-ui/core/AppBar';
import RaisedButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link, useLocation, BrowserRouter as Router } from "react-router-dom";
import axios from 'axios';
import Moment from 'moment';
import { Provider } from "react-redux";
import { createStore } from "redux";
import Header from '../Header/Header';
import './screen-basic.css';
import './queue-demo-basic.css';
import './font.css';


class Token_result extends Component {
constructor(props){
    // const store = createStore(reducer);
    super(props);
    this.printerData = [];
    this.state={
        tokenNo : "",
        expired_token1 : "",
        expired_token2 : "",
        expired_token3 : "" ,
        sec_flg : "",
        showdata : this.printerData,
    }
    this.appendData = this.appendData.bind(this);
}

async componentDidMount() {
    var apiBaseUrl = "http://localhost/api/login.php";
    // console.log("values in register handler",role);
    axios.get(apiBaseUrl+"?exp_token=true").then(response => response.data)
    .then((data) => {
        // alert(JSON.stringify(data));
        this.setState({expired_token1: data.exp_1,expired_token2: data.exp_2,expired_token3: data.exp_3})
        console.log(data);    
    })
    .catch(function (error) {
    console.log(error);
    });
        
}


appendData(token) {
    if (this.props.location.state.menu.service3) {
        this.printerData.push(<div  id="ticket" class="inner" style={{ bottom: "100px" }}><h3>Registration<strong>{token}</strong></h3></div>);
    } else{
        this.printerData.push(<div  id="ticket" class="inner" style={{ bottom: "130px" ,left: "90px" }}><h3>Registration<strong>{token}</strong></h3></div>);
    }
         this.setState({
            showdata : this.printerData,
         });
      }

async callNextQueue(section,token_no){
    alert(section + "/" + token_no);
        var apiBaseUrl = "http://localhost/api/login.php";
        // console.log("values in register handler",role);
        var self = this;
        //To be done:check for empty values before hitting submit
        if(section ==1){
            var section = "&section=1"
            var time = 9000
        }else if(section ==2){
            var section = "&section=2"
            var time = 12000
        }else if(section ==3){
            var section = "&section=3"
            var time = 15000
        }
        this.printerData = [];
        setTimeout(() => { 
            axios.post(apiBaseUrl+"?callnext=true"+section,JSON.stringify(token_no)).then(response => response.data)
            .then((data) => {
                alert(JSON.stringify(data));
                this.setState({expired_token1: data.exp_1,expired_token2: data.exp_2,expired_token3: data.exp_3})
                console.log(data);   
            })
            .catch(function (error) {
            console.log(error);
            });
        }, time);
    
}
async callAgainQueue(section,token_no){
    var apiBaseUrl = "http://localhost/api/login.php";
    // console.log("values in register handler",role);
    var self = this;
    //To be done:check for empty values before hitting submit
    if(section ==1){
        var section = "&section=1"
    }else if(section ==2){
        var section = "&section=2"
    }else if(section ==3){
        var section = "&section=3"
    }
    this.printerData = [];
    axios.post(apiBaseUrl+"?callagain=true"+section,JSON.stringify(token_no)).then(response => response.data)
    .then((data) => {
        // alert(JSON.stringify(data));
        this.setState({expired_token1: data.exp_1,expired_token2: data.exp_2,expired_token3: data.exp_3})
        console.log(data);    
    })
    .catch(function (error) {
    console.log(error);
    });
}
async generateQueueNumber(section){
    var apiBaseUrl = "http://localhost/api/login.php";
    // console.log("values in register handler",role);
    var self = this;
    //To be done:check for empty values before hitting submit
    if(section ==1){
        var section = "&section=1"
    }else if(section ==2){
        var section = "&section=2"
    }else if(section ==3){
        var section = "&section=3"
    }
    this.printerData = [];
    axios.get(apiBaseUrl+"?token=true"+section).then(response => response.data)
    .then((data) => {
        // alert(JSON.stringify(data));
        this.appendData(data.token);
        this.setState({sec_flg : data.sec_flg,tokenNo : data.token,expired_token1: data.exp_1,expired_token2: data.exp_2,expired_token3: data.exp_3})
        console.log(data);    
    })
    .catch(function (error) {
    console.log(error);
    });
}
render() {
    const renderAuthButton = ()=>{
            if (this.props.location.state.menu.service3) {
                return <li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(3)}>{this.props.location.state.menu.service3}</a></li>
            } else{
                return <li></li>
            }
    }
    const rendertr = ()=>{
            if (this.props.location.state.menu.service3) {
                return <tr> <td class='label'> <input type='hidden' name='serviceId' value='10'/> <input type='hidden' name='sectionId' value='10'/> {this.props.location.state.menu.service3} </td> <td>  <strong><span id='tdcounternumbersection10StatusZ'>3</span></strong></td> <td ><em id='tdqueuenumbersection10StatusZ'>{this.state.expired_token3}</em></td> </tr>      
            } else{
                return <tr></tr>
            }
    } 
    const rendercounter = ()=>{
            if (this.props.location.state.menu.service3) {
                return <ul class='releasing'><li id='b_screen_10'><strong>{this.props.location.state.menu.service3}</strong><a href='javascript:void(0);' class='ahref' onClick={(event) => this.callNextQueue(3,this.state.expired_token3)}>CALL NEXT</a><a href='javascript:void(0);' class='ahref' onClick={(event) => this.callAgainQueue(1,this.state.expired_token3)}>CALL AGAIN</a> </li></ul>   
            } else{
                return <ul></ul>
            }
    } 
    const renderdiv = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'b_screen'
            } else{
                return 'b_screen3'
            }
    }  
    const renderbasic = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'basic'
            } else{
                return 'basic_screen3'
            }
    } 
    const renderbscreen2 = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'b_screen2'
            } else{
                return 'b_screen2A'
            }
    } 
    const renderb_jumbotron = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'b_jumbotron'
            } else{
                return 'b_jumbotronA'
            }
    } 
    const renderpayment = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'payment'
            } else{
                return 'paymentA'
            }
    } 
    const renderevaluation = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'evaluation'
            } else{
                return 'evaluationA'
            }
    } 
    const renderled = ()=>{
            if (this.props.location.state.menu.service3) {
                return 'slide ledscreen'
            } else{
                return 'slide ledscreenA'
            }
    } 
    const page = "token";
    return (<div class={renderbasic()}><div class={renderdiv()}>
		<input type="hidden" id="start" name="start" class="start" value="" />
		<div class="totalqueue">
			<div id="jquery_jplayer_1"></div>
			<div id="jquery_jplayer_2"></div> 
			<div id="jquery_printerPlayer"></div>
		</div>
  
		<div class="step1">
    		<div id="printer" class={renderled()}>{this.printerData}</div>
    		<div class="b_printer-cover"></div>
    	</div>
    	<ul class={renderbscreen2()}>     
            <li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(1)}>{this.props.location.state.menu.service1}</a></li>
            <li><a href='javascript:void(0);' class='ahref' onClick={(event) => this.generateQueueNumber(2)}>{this.props.location.state.menu.service2}</a></li>
            {renderAuthButton()}
    	</ul>
    	<table border="0" cellspacing="4" cellpadding="0" class={renderb_jumbotron()}>
      		<tr>
        		<th>&nbsp;</th>
        		<th>WARD.NO</th>
        		<th>TOKEN</th>
      		</tr>
      		<tr>
      			<td colspan="3"></td>
      		</tr>
	  		 <tr> <td class='label'> <input type='hidden' name='serviceId' value='8'/> <input type='hidden' name='sectionId' value='8'/> {this.props.location.state.menu.service1} </td> <td>  <strong><span id='tdcounternumbersection8StatusZ'>1</span></strong></td> <td ><em id='tdqueuenumbersection8StatusZ'>{this.state.expired_token1}</em></td> </tr> 
             <tr> <td class='label'> <input type='hidden' name='serviceId' value='9'/> <input type='hidden' name='sectionId' value='9'/> {this.props.location.state.menu.service2} </td> <td>  <strong><span id='tdcounternumbersection9StatusZ'>2</span></strong></td> <td ><em id='tdqueuenumbersection9StatusZ'>{this.state.expired_token2}</em></td> </tr> 
             {rendertr()}
    	</table>

		<ul class={renderevaluation()}><li id='b_screen_8'><strong>{this.props.location.state.menu.service1}</strong><a href='javascript:void(0);' class='ahref' onClick={(event) => this.callNextQueue(1,this.state.expired_token1)}>CALL NEXT</a><a href='javascript:void(0);' class='ahref' onClick={(event) => this.callAgainQueue(1,this.state.expired_token1)}>CALL AGAIN</a> </li></ul>
        <ul class={renderpayment()}><li id='b_screen_9'><strong>{this.props.location.state.menu.service2}</strong><a href='javascript:void(0);' class='ahref' onClick={(event) => this.callNextQueue(2,this.state.expired_token2)}>CALL NEXT</a><a href='javascript:void(0);' class='ahref' onClick={(event) => this.callAgainQueue(1,this.state.expired_token2)}>CALL AGAIN</a> </li></ul>
        {rendercounter()}
  	     </div>
    </div> 

);
  }
}
export default Token_result;
