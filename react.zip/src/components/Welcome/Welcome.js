import React, {Component} from 'react';
import './Welcome.css';
class Welcome extends Component {
render() {
return (
<div className="row " id="Body">
<div className="medium-12 columns cc">
<h2 id="welcomeText">Welcome</h2>
<a href="/Calculator" className="button">Calculator</a>
<a href="/ImageCompressor" className="button success">ImageCompressor</a>
<a href="/Login" className="button success">Login</a>
</div>
</div>
);
}
}
export default Welcome;