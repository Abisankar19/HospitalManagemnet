import React from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import Welcome from '././components/Welcome/Welcome';
import NotFound from '././components/NotFound/NotFound';
import Sidebar from '././components/Sidebar/Sidebar';
import ImageCompressor from '././components/ImageCompressor';
import Calculator from '././components/Calculator/Calculator';
import List from '././components/List/List';
import Login from '././components/Login/Login';
import Token from '././components/Token/Token';
import Token_result from '././components/Token_Call/Token_result';
import Register from '././components/Register/Register';
import shop from '././components/Shop/Shop';
// import Home from '././components/Home/Home';

const Routes = () => (
<BrowserRouter >
<Switch>
<Route exact path="/" component={Login}/>
<Route path="/ImageCompressor" component={ImageCompressor}/>
<Route path="/Calculator" component={Calculator}/>
<Route path="/List" component={List}/>
<Route path="/Login" component={Login}/>
<Route path="/Register" component={Register}/>
<Route path="/Token" component={Token}/>
<Route path="/token_no" component={Token_result}/>
<Route path="/shop" component={shop}/>
</Switch>
</BrowserRouter>
);

export default Routes;